import { useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { DocumentIntake } from '@/components/dashboard/DocumentIntake';
import { AgentPipeline } from '@/components/dashboard/AgentPipeline';
import { CaseSummary } from '@/components/dashboard/CaseSummary';
import { SupervisorExplanation } from '@/components/dashboard/SupervisorExplanation';
import { RiskBreakdownChart } from '@/components/dashboard/RiskBreakdownChart';
import { UndervaluationChart } from '@/components/dashboard/UndervaluationChart';
import { ComplianceMap } from '@/components/dashboard/ComplianceMap';
import { mockComplianceCases } from '@/data/complianceData';
import { Card, CardContent } from '@/components/ui/card';
import { FileCheck, AlertTriangle, Scale, CheckCircle, Terminal, Activity } from 'lucide-react';

const Dashboard = () => {
  const [selectedCase] = useState(mockComplianceCases[0]);

  const stats = [
    { label: 'CASES_PROCESSED', value: 127, icon: FileCheck, description: 'This month', color: 'text-foreground' },
    { label: 'FLAGGED', value: 18, icon: AlertTriangle, description: 'Require review', color: 'text-amber-400' },
    { label: 'UNDER_REVIEW', value: 7, icon: Scale, description: 'In progress', color: 'text-blue-400' },
    { label: 'COMPLIANT', value: 102, icon: CheckCircle, description: '80% rate', color: 'text-emerald-400' },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div className="relative">
          <div className="absolute -left-3 top-0 bottom-0 w-1 bg-gradient-to-b from-primary via-primary/50 to-transparent rounded-full" />
          <div className="flex items-center gap-2 mb-1">
            <Terminal className="w-5 h-5 text-primary" />
            <h1 className="text-2xl font-bold text-foreground font-mono">COMPLIANCE_DASHBOARD</h1>
            <span className="flex items-center gap-1 ml-2 px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-mono">
              <Activity className="w-3 h-3" />
              ACTIVE
            </span>
          </div>
          <p className="text-muted-foreground text-sm font-mono">// Document-based compliance analysis and case management</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat, index) => (
            <div key={index} className="tech-card p-4 hover:tech-glow transition-all duration-300">
              <div className="flex items-center justify-between mb-2">
                <stat.icon className={`h-5 w-5 ${stat.color}`} />
                <span className="text-[10px] text-muted-foreground font-mono uppercase">{stat.description}</span>
              </div>
              <p className={`text-3xl font-bold font-mono ${stat.color}`}>{stat.value}</p>
              <p className="text-xs text-muted-foreground font-mono mt-1">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Main Grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="space-y-6">
            <DocumentIntake />
            <AgentPipeline />
          </div>

          {/* Center Column */}
          <div className="space-y-6">
            <ComplianceMap />
            <div className="grid grid-cols-2 gap-4">
              <RiskBreakdownChart />
              <UndervaluationChart />
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            <CaseSummary caseData={selectedCase} />
            <SupervisorExplanation
              caseId={selectedCase.id}
              flagReason="The declared property value is 40% below the estimated market value based on circle rates and comparable transactions in the area."
              reasoning="The Document Agent extracted a declared value of ₹27,00,000 while the Data Intelligence Agent cross-referenced current circle rates indicating a minimum value of ₹45,00,000. This discrepancy exceeds the 30% threshold for automatic flagging."
              nextSteps={[
                'Request updated valuation certificate from registered valuer',
                'Cross-verify with recent sale deeds in the same locality',
                'Check for any exemptions or special circumstances',
                'Schedule review with senior compliance officer if discrepancy persists',
              ]}
              confidenceScore={87}
            />
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Dashboard;
