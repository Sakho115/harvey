import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Brain, CheckCircle2, AlertTriangle, ArrowRight } from 'lucide-react';

interface SupervisorExplanationProps {
  caseId: string;
  flagReason: string;
  reasoning: string;
  nextSteps: string[];
  confidenceScore: number;
}

export const SupervisorExplanation = ({
  caseId,
  flagReason,
  reasoning,
  nextSteps,
  confidenceScore,
}: SupervisorExplanationProps) => {
  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-primary" />
            <CardTitle className="text-lg font-semibold text-foreground">AI Supervisor Explanation</CardTitle>
          </div>
          <Badge variant="outline" className="text-xs text-muted-foreground">
            For Reviewing Officer
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Why Flagged */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-orange-500" />
            <span className="text-sm font-medium text-foreground">Why This Case Was Flagged</span>
          </div>
          <p className="text-sm text-muted-foreground pl-6">{flagReason}</p>
        </div>

        {/* Reasoning */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-foreground">Analysis Reasoning</span>
          </div>
          <p className="text-sm text-muted-foreground pl-6">{reasoning}</p>
        </div>

        {/* Next Steps */}
        <div className="space-y-2">
          <span className="text-sm font-medium text-foreground">Recommended Next Steps</span>
          <div className="space-y-1.5 pl-2">
            {nextSteps.map((step, index) => (
              <div key={index} className="flex items-start gap-2 text-sm text-muted-foreground">
                <ArrowRight className="w-3.5 h-3.5 mt-0.5 text-primary/70" />
                <span>{step}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Confidence Score */}
        <div className="flex items-center justify-between pt-2 border-t border-border">
          <span className="text-sm text-muted-foreground">Confidence Score</span>
          <div className="flex items-center gap-2">
            <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary rounded-full transition-all duration-500"
                style={{ width: `${confidenceScore}%` }}
              />
            </div>
            <span className="text-sm font-medium text-foreground">{confidenceScore}%</span>
          </div>
        </div>

        {/* Disclaimer */}
        <p className="text-xs text-muted-foreground/70 italic pt-2">
          This analysis supports human decision-making. Final determination rests with the reviewing officer.
        </p>
      </CardContent>
    </Card>
  );
};
