import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Upload, FileText, Check, Circle, Loader2, Terminal } from 'lucide-react';
import { documentIntakeSteps } from '@/data/complianceData';

interface IntakeStep {
  label: string;
  completed: boolean;
}

export const DocumentIntake = () => {
  const [steps, setSteps] = useState<IntakeStep[]>(documentIntakeSteps);
  const [uploading, setUploading] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([]);

  const handleUpload = () => {
    setUploading(true);
    setTimeout(() => {
      setUploadedFiles(['Sale_Deed_2024.pdf', 'Stamp_Duty_Receipt.pdf']);
      setUploading(false);
      let stepIndex = 0;
      const interval = setInterval(() => {
        if (stepIndex < steps.length) {
          setSteps(prev => prev.map((step, i) => 
            i === stepIndex ? { ...step, completed: true } : step
          ));
          stepIndex++;
        } else {
          clearInterval(interval);
        }
      }, 800);
    }, 1500);
  };

  return (
    <div className="tech-card">
      <div className="px-4 py-3 border-b border-border/30 flex items-center gap-2">
        <Terminal className="w-4 h-4 text-primary" />
        <h3 className="font-semibold text-foreground font-mono text-sm">DOCUMENT_INTAKE</h3>
      </div>
      <div className="p-4 space-y-4">
        {/* Upload Area */}
        <div className="border border-dashed border-primary/30 rounded-lg p-6 text-center hover:border-primary/60 hover:bg-primary/5 transition-all cursor-pointer group">
          <Upload className="w-8 h-8 mx-auto mb-3 text-primary/50 group-hover:text-primary transition-colors" />
          <p className="text-sm text-foreground font-mono mb-1">Upload Documents</p>
          <p className="text-xs text-muted-foreground mb-3 font-mono">
            Sale_Deed.pdf | Stamp_Duty.pdf | Registration_Extract.pdf
          </p>
          <Button 
            size="sm" 
            onClick={handleUpload} 
            disabled={uploading}
            className="bg-primary text-primary-foreground font-mono"
          >
            {uploading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                PROCESSING...
              </>
            ) : (
              'SELECT_FILES'
            )}
          </Button>
        </div>

        {/* Uploaded Files */}
        {uploadedFiles.length > 0 && (
          <div className="space-y-2">
            {uploadedFiles.map((file, index) => (
              <div key={index} className="flex items-center gap-2 text-sm bg-primary/5 border border-primary/20 rounded px-3 py-2 font-mono">
                <FileText className="w-4 h-4 text-primary" />
                <span className="text-foreground text-xs">{file}</span>
                <Check className="w-4 h-4 text-emerald-500 ml-auto" />
              </div>
            ))}
          </div>
        )}

        {/* Step Tracker */}
        <div className="space-y-2 pt-2">
          <p className="text-[10px] font-mono text-primary uppercase tracking-wider">PROCESSING_STATUS</p>
          {steps.map((step, index) => (
            <div key={index} className="flex items-center gap-3 font-mono">
              {step.completed ? (
                <div className="w-5 h-5 rounded bg-emerald-500/20 flex items-center justify-center">
                  <Check className="w-3 h-3 text-emerald-400" />
                </div>
              ) : (
                <Circle className="w-5 h-5 text-muted-foreground/30" />
              )}
              <span className={`text-xs ${step.completed ? 'text-emerald-400' : 'text-muted-foreground/50'}`}>
                {step.completed ? '✓' : '○'} {step.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
