import { Badge } from '@/components/ui/badge';
import { ComplianceCase } from '@/data/complianceData';
import { FileText, MapPin, Calendar, AlertCircle, Database } from 'lucide-react';
import { format } from 'date-fns';

interface CaseSummaryProps {
  caseData: ComplianceCase;
}

const getStatusBadge = (status: ComplianceCase['status']) => {
  const styles: Record<string, string> = {
    'compliant': 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    'flagged': 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    'under-review': 'bg-blue-500/10 text-blue-400 border-blue-500/30',
    'escalated': 'bg-red-500/10 text-red-400 border-red-500/30',
  };
  return styles[status] || '';
};

const getRiskBadge = (level: ComplianceCase['riskLevel']) => {
  const styles: Record<string, string> = {
    'low': 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    'medium': 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30',
    'high': 'bg-orange-500/10 text-orange-400 border-orange-500/30',
    'critical': 'bg-red-500/10 text-red-400 border-red-500/30',
  };
  return styles[level] || '';
};

export const CaseSummary = ({ caseData }: CaseSummaryProps) => {
  return (
    <div className="tech-card">
      <div className="px-4 py-3 border-b border-border/30 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Database className="w-4 h-4 text-primary" />
          <h3 className="font-semibold text-foreground font-mono text-sm">CASE_SUMMARY</h3>
        </div>
        <FileText className="w-4 h-4 text-muted-foreground" />
      </div>
      <div className="p-4 space-y-3">
        {/* Case ID */}
        <div className="flex items-center justify-between py-2 border-b border-border/20">
          <span className="text-xs text-muted-foreground font-mono">CASE_ID</span>
          <span className="font-mono text-sm font-medium text-primary">{caseData.id}</span>
        </div>

        {/* Case Type */}
        <div className="flex items-center justify-between py-2 border-b border-border/20">
          <span className="text-xs text-muted-foreground font-mono">TYPE</span>
          <span className="text-sm text-foreground">{caseData.caseType}</span>
        </div>

        {/* Compliance Status */}
        <div className="flex items-center justify-between py-2 border-b border-border/20">
          <span className="text-xs text-muted-foreground font-mono">STATUS</span>
          <Badge variant="outline" className={`capitalize text-xs font-mono ${getStatusBadge(caseData.status)}`}>
            {caseData.status.replace('-', '_')}
          </Badge>
        </div>

        {/* Risk Level */}
        <div className="flex items-center justify-between py-2 border-b border-border/20">
          <span className="text-xs text-muted-foreground font-mono">RISK_LEVEL</span>
          <Badge variant="outline" className={`capitalize text-xs font-mono ${getRiskBadge(caseData.riskLevel)}`}>
            {caseData.riskLevel.toUpperCase()}
          </Badge>
        </div>

        {/* Priority */}
        <div className="flex items-center justify-between py-2 border-b border-border/20">
          <span className="text-xs text-muted-foreground font-mono">PRIORITY</span>
          <span className="text-sm font-mono text-foreground">P{caseData.priority}</span>
        </div>

        {/* Location */}
        <div className="flex items-center justify-between py-2 border-b border-border/20">
          <span className="text-xs text-muted-foreground font-mono flex items-center gap-1">
            <MapPin className="w-3 h-3" /> LOCATION
          </span>
          <span className="text-sm text-foreground">{caseData.registrationOffice}</span>
        </div>

        {/* Submitted */}
        <div className="flex items-center justify-between py-2 border-b border-border/20">
          <span className="text-xs text-muted-foreground font-mono flex items-center gap-1">
            <Calendar className="w-3 h-3" /> SUBMITTED
          </span>
          <span className="text-sm text-foreground font-mono">{format(caseData.submittedAt, 'dd-MM-yyyy HH:mm')}</span>
        </div>

        {/* Valuation Details */}
        <div className="bg-muted/10 border border-border/30 rounded p-3 space-y-2">
          <p className="text-[10px] font-mono text-primary uppercase tracking-wider">VALUATION_DATA</p>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <p className="text-muted-foreground text-[10px] font-mono">MARKET_VALUE</p>
              <p className="font-mono text-sm text-foreground">₹{caseData.propertyValue.toLocaleString()}</p>
            </div>
            <div>
              <p className="text-muted-foreground text-[10px] font-mono">DECLARED_VALUE</p>
              <p className="font-mono text-sm text-foreground">₹{caseData.declaredValue.toLocaleString()}</p>
            </div>
          </div>
          {caseData.undervaluationPercent > 0 && (
            <div className="flex items-center gap-2 pt-1 border-t border-border/20">
              <AlertCircle className="w-4 h-4 text-amber-400" />
              <span className="text-xs text-amber-400 font-mono">
                {caseData.undervaluationPercent}% UNDERVALUATION_DETECTED
              </span>
            </div>
          )}
        </div>

        {/* Recommended Action */}
        <div className="bg-primary/5 border border-primary/20 rounded p-3">
          <p className="text-[10px] font-mono text-primary uppercase tracking-wider mb-1">RECOMMENDED_ACTION</p>
          <p className="text-xs text-foreground">{caseData.recommendedAction}</p>
        </div>
      </div>
    </div>
  );
};
