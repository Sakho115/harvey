import { Check, AlertTriangle, Clock, FileSearch, Brain, Shield, Scale, Briefcase, UserCheck, Cpu } from 'lucide-react';
import { agentPipeline, AgentPipelineStage } from '@/data/complianceData';
import { format } from 'date-fns';

const getAgentIcon = (id: string) => {
  const icons: Record<string, React.ElementType> = {
    'doc-agent': FileSearch,
    'data-agent': Brain,
    'risk-agent': AlertTriangle,
    'compliance-agent': Shield,
    'case-agent': Briefcase,
    'supervisor': UserCheck,
  };
  return icons[id] || Scale;
};

const getStatusStyles = (status: AgentPipelineStage['status']) => {
  switch (status) {
    case 'completed':
      return { bg: 'bg-emerald-500/10', border: 'border-emerald-500/30', icon: 'text-emerald-400', text: 'text-emerald-400' };
    case 'flagged':
      return { bg: 'bg-amber-500/10', border: 'border-amber-500/30', icon: 'text-amber-400', text: 'text-amber-400' };
    case 'processing':
      return { bg: 'bg-blue-500/10', border: 'border-blue-500/30', icon: 'text-blue-400', text: 'text-blue-400' };
    default:
      return { bg: 'bg-muted/20', border: 'border-border/30', icon: 'text-muted-foreground', text: 'text-muted-foreground' };
  }
};

export const AgentPipeline = () => {
  return (
    <div className="tech-card">
      <div className="px-4 py-3 border-b border-border/30 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-primary" />
          <h3 className="font-semibold text-foreground font-mono text-sm">AGENT_PIPELINE</h3>
        </div>
        <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          RUNNING
        </span>
      </div>
      <div className="p-4">
        <div className="space-y-2">
          {agentPipeline.map((stage, index) => {
            const Icon = getAgentIcon(stage.id);
            const styles = getStatusStyles(stage.status);
            
            return (
              <div key={stage.id} className="relative">
                {/* Connector Line */}
                {index < agentPipeline.length - 1 && (
                  <div className="absolute left-[18px] top-10 w-px h-4 bg-gradient-to-b from-primary/30 to-transparent" />
                )}
                
                <div className={`flex items-start gap-3 p-2.5 rounded border ${styles.bg} ${styles.border} transition-all hover:scale-[1.01]`}>
                  <div className={`w-8 h-8 rounded flex items-center justify-center ${styles.bg} border ${styles.border}`}>
                    <Icon className={`w-4 h-4 ${styles.icon}`} />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono text-xs text-foreground">{stage.name}</span>
                      <div className="flex items-center gap-1.5">
                        {stage.status === 'completed' && <Check className="w-3 h-3 text-emerald-400" />}
                        {stage.status === 'flagged' && <AlertTriangle className="w-3 h-3 text-amber-400" />}
                        {stage.status === 'processing' && <Clock className="w-3 h-3 text-blue-400 animate-pulse" />}
                        <span className={`text-[10px] font-mono uppercase ${styles.text}`}>
                          {stage.status}
                        </span>
                      </div>
                    </div>
                    {stage.findings && (
                      <p className="text-[10px] text-muted-foreground font-mono mt-0.5">{stage.findings}</p>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
